// td태그 9개를 선택한다.
let $tdList = document.querySelectorAll(".box");
console.log($tdList);

// 위에서 선택한 9개의 td태그에 이벤트를 적용한다.
// => click 이벤트
for (let i = 0; i < $tdList.length; i++) {
    $tdList[i].addEventListener("click", clickEvent);
}

// 위에서 만든 1차원의 td리스트를 2차원으로 변경한다.
let $tempList = [];
let temp = [];
for (let i = 0; i < $tdList.length; i++) {
    temp.push($tdList[i]);
    if (i % 3 == 2) {
        $tempList.push(temp);
        temp = [];
    }
}

// 2인용 게임이기 때문에, 차례변수를 설정한다.
// true(O표시), false(X표시)
let turn = true;
let count = 0;
// 함수를 생성한다.
function clickEvent() {
    count++;
    for (let i = 0; i < $tempList.length; i++) {
        for (let j = 0; j < $tempList[i].length; j++) {
            // tdList 9개 중에 내가 선택한 것(this)과
            // 일치하는 것을 찾는다.
            if (this == $tempList[i][j]) {
                // 처음 선택한 td이면
                if ($tempList[i][j].innerText == "") {
                    // O차례이면
                    if (turn == true) {
                        // td태그안에 글자를 작성한다.
                        $tempList[i][j].innerHTML = "<span style='color:blue;'>O</span>";
                        turn = false;
                    } else {
                        $tempList[i][j].innerHTML = "<span style='color:red;'>X</span>";
                        turn = true;
                    }
                }
            }
        }
    }

    // 사용자가 td를 선택할 때마다 승자, 패자를 검증한다.
    winnerCheck();
}

// 누가 이겼는지 판단하기 위한 변수를 설정한다.
// 1(O 이김) 2(X 이김) 3(비김)
let winner = 0;
// 승자, 패자를 판별하는 함수를 만든다.
function winnerCheck() {
    // 가로 검사
    for (let i = 0; i < $tempList.length; i++) {
        let countO = 0;
        let countX = 0;
        for (let j = 0; j < $tempList[i].length; j++) {
            if ($tempList[i][j].innerText == "O") {
                countO++;
            } else if ($tempList[i][j].innerText == "X") {
                countX++;
            }
        }

        if (countO == 3) {
            winner = 1;
        } else if (countX == 3) {
            winner = 2;
        }
    }

    // 세로 검사
    for (let i = 0; i < 3; i++) {
        let countO = 0;
        let countX = 0;
        for (let j = 0; j < $tempList.length; j++) {
            if ($tempList[j][i].innerText == "O") {
                countO++;
            } else if ($tempList[j][i].innerText == "X") {
                countX++;
            }
        }
        if (countO == 3) {
            winner = 1;
        } else if (countX == 3) {
            winner = 2;
        }
    }

    // 대각선 \ 검사
    if (
        $tempList[0][0].innerText == "O" &&
        $tempList[1][1].innerText == "O" &&
        $tempList[2][2].innerText == "O"
    ) {
        winner = 1;
    }

    if (
        $tempList[0][0].innerText == "X" &&
        $tempList[1][1].innerText == "X" &&
        $tempList[2][2].innerText == "X"
    ) {
        winner = 2;
    }

    // 대각선 / 검사
    if (
        $tempList[0][2].innerText == "O" &&
        $tempList[1][1].innerText == "O" &&
        $tempList[2][0].innerText == "O"
    ) {
        winner = 1;
    }

    if (
        $tempList[0][2].innerText == "X" &&
        $tempList[1][1].innerText == "X" &&
        $tempList[2][0].innerText == "X"
    ) {
        winner = 2;
    }

    if (winner == 1) {
        alert("O가 이겼습니다!");
    } else if (winner == 2) {
        alert("X가 이겼습니다!");
    }

    ckFooter();
}

function ckFooter() {
    let $msg = document.querySelector("#msg");

    if (winner == 1 || winner == 2) {
        if (winner == 1) {
            $msg.innerText = "Player O 승리";
        }
        if (winner == 2) {
            $msg.innerText = "Player X 승리";
        }
    }

    if (count == 9 && winner == 0) {
        $msg.innerText = "DRAW";
    }
}
